# Agent Fleet Map — adoptedbygrace.net
> Last updated: 2026-03-28 (v2 — Inspector & Designer added, Architect role changed)

## Fleet Overview (9 Agents)

| Agent | Role | Primary Output | Cadence |
|-------|------|---------------|---------|
| **abg-builder** | Create new content pages | HTML pages (questions, OT studies, etc.) | 2x/month |
| **abg-refiner** | Deepen & polish existing pages | Improved arguments, quotes, cross-refs | Weekly |
| **abg-harmonizer** | Navigation sync + missing hub pages | Mega-menu enforcement, new hubs | As needed |
| **abg-inspector** | Functional testing — every link, button, element | INSPECTION-REPORT.md + fixes | After each build cycle |
| **abg-designer** | Design/UX QA — spacing, consistency, mobile comfort | DESIGN-REPORT.md + fixes | After each build cycle |
| **abg-architect** | Technical excellence (SEO, a11y, UX, perf) + optimize agent prompts + recommend new agents | Site-wide tech improvements + improved SKILL.md files + email to Aaron | 1x/month |
| **abg-storyteller** | Original stories, parables, narratives | Story HTML pages across 5 categories | 2x/month |
| **abg-visionary** | Creative ideation & strategic planning | VISION.md ideas, ROADMAP backlog items | Monthly |
| **abg-deploy** | Publish to Netlify production | Live deployment | After each session |

## Agent Responsibilities

### abg-builder
- Reads ROADMAP backlog, picks highest-priority unchecked item
- Builds ONE complete page to maximum depth (5-7 arguments, 5-7 objections, Greek/Hebrew, theologian quotes)
- Updates hub page with new card
- Cross-references to related pages
- **Must use mega-menu navigation** on all new pages

### abg-refiner
- Targets newest Builder output first, then weakest pages
- Adds 1-2 new arguments, 2+ theologian quotes, 3+ cross-references per page
- Fixes Greek errors, weak conclusions, missing "Further Reading"
- **Checks for mega-menu nav** before content work; upgrades if needed

### abg-harmonizer
- **Primary:** Enforce mega-menu navigation across ALL pages
- **Secondary:** Build missing hub pages (secular-evidence, analogies-illustrations, creeds-confessions)
- **Tertiary:** Broken link audit, footer consistency
- Run this agent before major content pushes to ensure structural integrity

### abg-inspector (NEW — 2026-03-28)
- **Systematically tests every functional element on every page**
- Tests: all navigation links, dropdown behavior, internal links, interactive elements (TULIP selector, quiz, back-to-top, share buttons), forms, external links, page integrity, asset verification, sitemap completeness
- Outputs: INSPECTION-REPORT.md with critical/warning/info issues
- **Fixes critical issues directly** (broken links, missing pages, broken JS)
- Run after every build cycle — catches what Builder/Refiner might break

### abg-designer (NEW — 2026-03-28)
- **Design and UX quality assurance across every page**
- Checks: spacing & rhythm (especially mobile), typography consistency, color system compliance, component consistency (cards, buttons, blockquotes), mobile experience, visual polish, reading comfort
- Has full design system reference embedded (colors, fonts, spacing breakpoints)
- Outputs: DESIGN-REPORT.md with issues found and fixed
- **Fixes design issues directly** — spacing, inconsistent styling, mobile problems
- Run after every build cycle — the user should never find design bugs before this agent does

### abg-architect (REVISED — 2026-03-28)
- All original technical work RETAINED: SEO, accessibility, UX, performance, consistency enforcement
- Brings new pages to technical standard (canonical URLs, JSON-LD, meta tags, sitemap)
- Implements site-wide improvements across all 110+ pages
- **Mega-menu enforcement** is high priority for any pages still using old nav
- **ADDED:** Every session, reads and optimizes all other agents' SKILL.md prompts for maximum output quality
- **ADDED:** Evaluates fleet workflow gaps, emails recommendations for new agents to Aaron (formanna77@gmail.com)
- **REMOVED:** Does NOT create new agents. Only recommends — Aaron approves.

### abg-storyteller
- Writes original stories/parables illuminating sovereign grace
- 5 categories: Children, Humor, Dark, Tender, Thought Experiments
- 1,500-3,000 words per story with doctrine section at end
- Updates stories.html hub with new cards

### abg-visionary
- Pure ideation — does NOT build pages
- Generates ideas across 5 categories (content, creative angles, design, theological deep cuts, strategy)
- Outputs to VISION.md, top ideas go to ROADMAP backlog
- Run monthly to keep the creative pipeline full

### abg-deploy
- Deploys to Netlify (site ID: b141f13b-8829-4765-9f2b-cdfed3eec911)
- Sanity check before deploy (file count, index.html integrity)
- Logs deployment status to ROADMAP

## Suggested Run Order
1. **Builder** → creates new pages
2. **Refiner** → deepens new + existing pages
3. **Harmonizer** → ensures nav consistency after new pages added
4. **Inspector** → tests every link and function (catches breakage early)
5. **Designer** → checks every page looks right (catches visual issues)
6. **Deploy** → push to production (only after Inspector + Designer clear it)
7. **Architect** → monthly prompt optimization + gap analysis + email to Aaron
8. **Visionary** → monthly ideation (independent of build cycle)
9. **Storyteller** → independent creative sessions (2x/month)

## Quality Gate
**Inspector and Designer MUST run before Deploy.** No deployment without functional and visual QA passing.

## Navigation Standard
ALL agents must produce pages with the **mega-menu navigation** (dropdowns for Doctrine, Apologetics, Explore, and History). The canonical reference is `index.html`. Logo text: `Adopted by Grace` (title case). Old flat 4-link nav is DEPRECATED.

## File Locations
- Agent SKILL.md files: `/Users/aaronforman/Documents/adoptedbygracewebsite/Claude/Scheduled/`
- Website files: `/Users/aaronforman/Documents/adoptedbygracewebsite/`
- Roadmap: `/Users/aaronforman/Documents/adoptedbygracewebsite/ROADMAP.md`
- Vision notes: `/Users/aaronforman/Documents/adoptedbygracewebsite/VISION.md`
